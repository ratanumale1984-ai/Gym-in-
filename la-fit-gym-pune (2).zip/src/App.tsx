/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export default function App() {
  const galleryImages = [
    '/Screenshot_20260511-085247.png',
    '/Screenshot_20260511-085309.png',
    '/Screenshot_20260511-085320.png',
    '/Screenshot_20260511-085340.png',
    '/Screenshot_20260511-085351.png',
    '/Screenshot_20260511-085138.png',
  ];

  return (
    <div className="bg-black text-white min-h-screen font-sans overflow-hidden">
      {/* Navbar */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-black/80 backdrop-blur border-b border-gray-800 px-6 py-4 flex items-center justify-between">
        <h1 className="text-3xl font-extrabold tracking-wide text-red-500">LA FIT GYM</h1>

        <div className="hidden lg:flex gap-8 text-sm uppercase tracking-wider">
          <a href="#home" className="hover:text-red-500 transition">Home</a>
          <a href="#about" className="hover:text-red-500 transition">About</a>
          <a href="#services" className="hover:text-red-500 transition">Services</a>
          <a href="#plans" className="hover:text-red-500 transition">Plans</a>
          <a href="#gallery" className="hover:text-red-500 transition">Gallery</a>
          <a href="#contact" className="hover:text-red-500 transition">Contact</a>
        </div>
      </nav>

      {/* Hero Section */}
      <section
        id="home"
        className="relative h-screen flex items-center justify-center text-center px-6"
      >
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage: "url('/Screenshot_20260511-121751.png')",
          }}
        ></div>
        <div className="absolute inset-0 bg-black/70"></div>

        <div className="relative z-10 max-w-5xl">
          <p className="uppercase tracking-[8px] text-red-500 mb-6">Best Gym In Pune</p>

          <h1 className="text-6xl md:text-8xl font-black leading-tight mb-8">
            Build Your <span className="text-red-500">Dream Body</span>
          </h1>

          <p className="text-xl text-gray-300 leading-8 mb-10 max-w-3xl mx-auto">
            Join La Fit GYM Kothrud Pune and experience premium fitness training,
            imported equipment, expert trainers, fat loss programs, bodybuilding,
            cardio sessions, strength training, and complete body transformation.
          </p>

          <div className="flex flex-wrap justify-center gap-5">
            <button className="bg-red-600 hover:bg-red-700 transition px-8 py-4 rounded-2xl text-lg font-bold shadow-2xl cursor-pointer">
              Join Membership
            </button>

            <button className="border-2 border-white hover:bg-white hover:text-black transition px-8 py-4 rounded-2xl text-lg font-bold cursor-pointer">
              Book Free Trial
            </button>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="bg-gray-950 py-20 px-6">
        <div className="max-w-7xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
          {[
            ['500+', 'Happy Members'],
            ['15+', 'Expert Trainers'],
            ['5.0★', 'Google Reviews'],
            ['100%', 'Transformation Support'],
          ].map(([number, label]) => (
            <div key={label} className="bg-black border border-gray-800 rounded-3xl p-10 shadow-2xl hover:border-red-500 transition">
              <h2 className="text-5xl font-black text-red-500 mb-4">{number}</h2>
              <p className="text-gray-300 text-lg">{label}</p>
            </div>
          ))}
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-24 px-6 max-w-7xl mx-auto grid lg:grid-cols-2 gap-16 items-center">
        <div>
          <img
            src="/Screenshot_20260511-085203.png"
            alt="Gym"
            className="rounded-3xl shadow-2xl"
          />
        </div>

        <div>
          <p className="uppercase tracking-[5px] text-red-500 mb-4">About Our Gym</p>

          <h2 className="text-5xl font-black mb-8 leading-tight">
            Pune’s Premium Fitness Destination
          </h2>

          <p className="text-gray-300 text-lg leading-9 mb-8">
            La Fit GYM is a luxury fitness center designed for serious fitness lovers.
            Our gym offers modern imported equipment, motivating trainers, premium interiors,
            cardio zones, muscle-building programs, weight-loss sessions, and a powerful atmosphere
            that pushes every member toward success.
          </p>

          <div className="space-y-5">
            <div className="bg-gradient-to-r from-red-600 to-orange-500 rounded-3xl p-6 shadow-2xl">
              <h3 className="text-2xl font-black mb-3">🔥 Hanuman Power Motivation Zone</h3>
              <p className="text-white text-lg leading-8 mb-6">
                Inspired by strength, discipline, focus, and unstoppable energy. Our gym atmosphere is designed to keep members motivated every day.
              </p>
              <div className="rounded-xl overflow-hidden shadow-2xl border-2 border-red-400/50 relative bg-black flex justify-center">
                <iframe
                  src="https://www.instagram.com/reel/DIUVqbxMvm3/embed"
                  className="w-full max-w-[400px] h-[550px]"
                  frameBorder="0"
                  scrolling="no"
                  allowTransparency={true}
                  title="Hanuman Power Motivation"
                ></iframe>
              </div>
            </div>
            <div className="bg-gray-900 border border-gray-800 rounded-2xl p-5">✔ Certified Fitness Trainers</div>
            <div className="bg-gray-900 border border-gray-800 rounded-2xl p-5">✔ Advanced Imported Equipment</div>
            <div className="bg-gray-900 border border-gray-800 rounded-2xl p-5">✔ Personal Training & Diet Plans</div>
            <div className="bg-gray-900 border border-gray-800 rounded-2xl p-5">✔ Clean & Premium Workout Environment</div>
          </div>
        </div>
      </section>

      {/* Services */}
      <section id="services" className="bg-gray-950 py-24 px-6">
        <div className="max-w-7xl mx-auto text-center">
          <p className="uppercase tracking-[5px] text-red-500 mb-4">Fitness Services</p>
          <h2 className="text-5xl font-black mb-16">Training Programs</h2>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-10">
            {[
              { name: 'Weight Loss Training', imageUrl: 'https://static.vecteezy.com/system/resources/thumbnails/017/709/338/small/man-body-before-and-after-weight-loss-in-flat-design-on-white-background-vector.jpg' },
              { name: 'Muscle Building', embedUrl: 'https://www.instagram.com/p/DQ1QDcEjPKt/embed' },
              { name: 'Cardio Training', imageUrl: 'https://images.pexels.com/photos/34761566/pexels-photo-34761566.jpeg' },
              { name: 'Strength Training', imageUrl: 'https://img.magnific.com/free-photo/strong-man-training-gym_1303-23478.jpg' },
              { name: 'Functional Workout' },
              { name: 'Zumba & Yoga', imageUrl: 'https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?q=80&w=1600&auto=format&fit=crop' },
            ].map((service) => (
              <div key={service.name} className="bg-black border border-gray-800 hover:border-red-500 transition rounded-3xl overflow-hidden shadow-2xl group flex flex-col">
                <div className={`relative overflow-hidden w-full flex justify-center bg-black ${service.embedUrl ? "h-[500px]" : "h-56"}`}>
                    {service.embedUrl ? (
                       <iframe
                         src={service.embedUrl}
                         className="w-full h-full border-0 pointer-events-auto"
                         scrolling="no"
                         allowTransparency={true}
                         title={service.name}
                       ></iframe>
                    ) : (
                        <img
                        src={service.imageUrl || "https://images.unsplash.com/photo-1518611012118-696072aa579a?q=80&w=1600&auto=format&fit=crop"}
                        alt={service.name}
                        className="absolute inset-0 w-full h-full object-cover group-hover:scale-110 transition duration-500"
                        />
                    )}
                </div>

                <div className="p-8 text-left flex-1 flex flex-col">
                  <h3 className="text-3xl font-bold mb-4">{service.name}</h3>
                  <p className="text-gray-400 leading-7 mb-6 flex-1">
                    Professional workout sessions designed for fast fitness transformation and better health.
                  </p>

                  <button className="bg-red-600 hover:bg-red-700 px-6 py-3 rounded-xl font-semibold w-fit cursor-pointer transition">
                    Learn More
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Transformation Banner */}
      <section className="relative py-40 text-center">
        <div className="absolute inset-0 bg-[url('/Screenshot_20260511-085351.png')] bg-cover bg-center"></div>
        <div className="absolute inset-0 bg-black/75"></div>

        <div className="relative z-10 max-w-4xl mx-auto px-6">
          <h2 className="text-6xl font-black leading-tight mb-8">
            No Excuses <span className="text-red-500">Only Results</span>
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-10">
            <div className="rounded-xl overflow-hidden shadow-2xl border-2 border-red-400/50 relative bg-black flex justify-center">
              <iframe
                src="https://www.instagram.com/reel/DWUK_lNDOpz/embed"
                className="w-full max-w-[400px] h-[550px]"
                frameBorder="0"
                scrolling="no"
                allowTransparency={true}
              ></iframe>
            </div>
            <div className="rounded-xl overflow-hidden shadow-2xl border-2 border-red-400/50 relative bg-black flex justify-center">
              <iframe
                src="https://www.instagram.com/reel/DWArjy2ASK9/embed"
                className="w-full max-w-[400px] h-[550px]"
                frameBorder="0"
                scrolling="no"
                allowTransparency={true}
              ></iframe>
            </div>
            <div className="rounded-xl overflow-hidden shadow-2xl border-2 border-red-400/50 relative bg-black flex justify-center">
              <iframe
                src="https://www.instagram.com/reel/DSm3o1PATc8/embed"
                className="w-full max-w-[400px] h-[550px]"
                frameBorder="0"
                scrolling="no"
                allowTransparency={true}
              ></iframe>
            </div>
            <div className="rounded-xl overflow-hidden shadow-2xl border-2 border-red-400/50 relative bg-black flex justify-center">
              <iframe
                src="https://www.instagram.com/reel/DOxdm9_iB6L/embed"
                className="w-full max-w-[400px] h-[550px]"
                frameBorder="0"
                scrolling="no"
                allowTransparency={true}
              ></iframe>
            </div>
          </div>

          <p className="text-xl text-gray-300 leading-8 mb-10">
            Push your limits and unlock your strongest version with professional guidance and premium fitness support.
          </p>

          <button className="bg-red-600 hover:bg-red-700 px-10 py-4 rounded-2xl text-xl font-bold shadow-2xl cursor-pointer transition">
            Start Today
          </button>
        </div>
      </section>

      {/* Membership */}
      <section id="plans" className="py-24 px-6 max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <p className="uppercase tracking-[5px] text-red-500 mb-4">Pricing Plans</p>
          <h2 className="text-5xl font-black">Choose Your Membership</h2>
        </div>

        <div className="grid md:grid-cols-3 gap-10">
          {[
            ['Monthly Plan', '₹1999'],
            ['Quarterly Plan', '₹4999'],
            ['Annual Plan', '₹14999'],
          ].map(([title, price]) => (
            <div key={title} className="bg-gray-900 border border-gray-800 hover:border-red-500 transition rounded-3xl p-10 text-center shadow-2xl relative overflow-hidden flex flex-col">
              <div className="absolute top-0 right-0 bg-red-600 text-white px-4 py-2 rounded-bl-2xl text-sm font-bold">
                Popular
              </div>

              <h3 className="text-3xl font-black mb-6">{title}</h3>
              <p className="text-5xl font-black text-red-500 mb-8">{price}</p>

              <ul className="space-y-4 text-gray-300 text-lg mb-10 flex-1 text-left">
                <li>✔ Unlimited Gym Access</li>
                <li>✔ Cardio & Strength Zone</li>
                <li>✔ Locker Facility</li>
                <li>✔ Trainer Guidance</li>
                <li>✔ Diet Consultation</li>
              </ul>

              <button className="bg-red-600 hover:bg-red-700 transition px-8 py-4 rounded-2xl text-lg font-bold w-full cursor-pointer mt-auto">
                Join Now
              </button>
            </div>
          ))}
        </div>
      </section>

      {/* Gallery */}
      <section id="gallery" className="bg-gray-950 py-24 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <p className="uppercase tracking-[5px] text-red-500 mb-4">Gallery</p>
            <h2 className="text-5xl font-black">Inside La Fit GYM</h2>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {galleryImages.map((img, index) => (
              <div key={index} className="overflow-hidden rounded-3xl shadow-2xl group cursor-pointer relative h-96">
                <img
                  src={img}
                  alt="Gym Gallery"
                  className="absolute inset-0 h-full w-full object-cover group-hover:scale-110 transition duration-500"
                />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-24 px-6 max-w-7xl mx-auto text-center">
        <p className="uppercase tracking-[5px] text-red-500 mb-4">Testimonials</p>
        <h2 className="text-5xl font-black mb-16">What Members Say</h2>

        <div className="grid md:grid-cols-3 gap-10">
          {[
            'Amazing trainers and premium atmosphere. Best gym in Pune.',
            'Excellent equipment and very motivating fitness environment.',
            'My transformation journey became possible because of La Fit Gym.',
          ].map((review, index) => (
            <div key={index} className="bg-gray-900 border border-gray-800 rounded-3xl p-10 shadow-2xl flex flex-col self-stretch">
              <p className="text-yellow-400 text-2xl mb-6">⭐⭐⭐⭐⭐</p>
              <p className="text-gray-300 text-lg leading-8 italic">“{review}”</p>
            </div>
          ))}
        </div>
      </section>

      {/* Contact */}
      <section id="contact" className="bg-gray-950 py-24 px-6">
        <div className="max-w-7xl mx-auto grid lg:grid-cols-2 gap-16 items-start">
          <div className="sticky top-24">
            <p className="uppercase tracking-[5px] text-red-500 mb-4">Contact Us</p>
            <h2 className="text-5xl font-black mb-10">Start Your Fitness Journey</h2>

            <div className="space-y-6 text-lg text-gray-300 leading-8">
              <div className="flex gap-4 items-start">
                <span className="text-2xl mt-1">📍</span>
                <p>4th Floor, Petrol Pump, Karve Rd, Opposite Karve Putla, Kothrud, Pune</p>
              </div>
              <div className="flex gap-4 items-center">
                 <span className="text-2xl">📞</span>
                 <p>+91 84088 04848</p>
              </div>
               <div className="flex gap-4 items-center">
                 <span className="text-2xl">🕒</span>
                 <p>Open Daily: 6:00 AM – 11:00 PM</p>
              </div>
               <div className="flex gap-4 items-center">
                 <span className="text-2xl">⭐</span>
                 <p>5.0 Rating On Google Reviews</p>
              </div>
            </div>
          </div>

          <div className="bg-black border border-gray-800 rounded-3xl p-10 shadow-2xl">
            <form className="space-y-6" onSubmit={(e) => e.preventDefault()}>
              <div>
                <input
                    type="text"
                    required
                    placeholder="Full Name"
                    className="w-full bg-gray-900 border border-gray-700 rounded-2xl p-5 focus:outline-none focus:border-red-500 transition text-white placeholder-gray-500"
                />
              </div>

              <div>
                <input
                    type="tel"
                    required
                    placeholder="Phone Number"
                    className="w-full bg-gray-900 border border-gray-700 rounded-2xl p-5 focus:outline-none focus:border-red-500 transition text-white placeholder-gray-500"
                />
              </div>

               <div>
                <input
                    type="email"
                    required
                    placeholder="Email Address"
                    className="w-full bg-gray-900 border border-gray-700 rounded-2xl p-5 focus:outline-none focus:border-red-500 transition text-white placeholder-gray-500"
                />
               </div>

              <div>
                <textarea
                    rows={6}
                    required
                    placeholder="Your Message"
                    className="w-full bg-gray-900 border border-gray-700 rounded-2xl p-5 focus:outline-none focus:border-red-500 transition text-white placeholder-gray-500 resize-none"
                ></textarea>
              </div>

              <button type="submit" className="bg-red-600 hover:bg-red-700 transition w-full py-4 rounded-2xl text-xl font-bold cursor-pointer">
                Send Inquiry
              </button>
            </form>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-gray-800 py-10 text-center text-gray-500 bg-black">
        <h3 className="text-3xl font-black text-red-500 mb-4">LA FIT GYM</h3>
        <p>© {new Date().getFullYear()} La Fit GYM Kothrud Pune. All Rights Reserved.</p>
      </footer>
    </div>
  );
}
