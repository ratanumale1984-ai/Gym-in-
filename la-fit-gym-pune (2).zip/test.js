import fs from 'fs';
try {
  fs.readdirSync('/tmp').forEach(file => {
    if (file.endsWith('.mp4')){
      console.log('/tmp: ' + file);
    }
  });
} catch (e) { }
